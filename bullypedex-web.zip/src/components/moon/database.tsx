import { ClockIcon, FileTextIcon, TruckIcon } from "lucide-react";
import Image from "next/image";

export default function Database() {
    return (
        <section className="grid grid-cols-2 gap-x-3 gap-y-8 px-6 py-16 md:gap-6 md:px-4 md:py-24 lg:px-[4%] xl:px-[6%]">
            <div className="col-span-2 space-y-4 md:col-span-1 md:space-y-6">
                <p className="text-[0.55rem] font-bold text-primary md:text-base">THE BULLY PEDEX DIFFERENCE</p>
                <h1 className="text-2xl font-black leading-tight tracking-tight md:text-4xl md:font-bold xl:text-6xl">
                    No Delays. No Excuses. <br />
                    <span className="text-primary">We Deliver Results.</span>
                </h1>
                <p className="text-[0.6rem] leading-relaxed text-muted-foreground md:text-base">
                    We collect all required information before approval, then prepare and ship your paperwork within 5 business days after approval.
                </p>
                <div className="col-span-2 grid grid-cols-1 gap-3 md:grid-cols-3 md:gap-6">
                    <div className="flex items-center gap-3 md:block md:space-y-4">
                        <div className="w-min rounded-full bg-primary p-2 text-background md:p-4">
                            <FileTextIcon className="size-4 md:size-8" />
                        </div>
                        <p className="text-xs font-semibold md:text-base">
                            Official Bully Pedex registration
                        </p>
                    </div>
                    <div className="flex items-center gap-3 md:block md:space-y-4">
                        <div className="w-min rounded-full bg-primary p-2 text-background md:p-4">
                            <ClockIcon className="size-4 md:size-8" />
                        </div>
                        <p className="text-xs font-semibold md:text-base">
                            Three generation pedigree
                        </p>
                    </div>
                    <div className="flex items-center gap-3 md:block md:space-y-4">
                        <div className="w-min rounded-full bg-primary p-2 text-background md:p-4">
                            <TruckIcon className="size-4 md:size-8" />
                        </div>
                        <p className="text-xs font-semibold md:text-base">
                            Professionally prepared paperwork
                        </p>
                    </div>
                </div>
            </div>
            <div className="relative row-start-1 w-full self-start md:row-auto">
                <Image src="/cert1.webp" alt="Certificate 1" width={500 * 2} height={300 * 2} className="h-auto w-full object-cover" />
                <div className="">
                    <Image src="/cert2.webp" alt="Certificate 2" width={500 * 2} height={300 * 2} className="absolute -bottom-[55%] -left-[8%] h-auto w-4/5 object-contain object-top-left md:-bottom-[95%] md:-left-[5%]" />
                </div>
            </div>
        </section>
    )
}