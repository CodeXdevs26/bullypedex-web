'use client';
import { cn } from '@/lib/utils';
import type React from 'react';
import { type JSX, useEffect, useState } from 'react';

function Blocks({
    activeDivs,
    divClass,
    classname,
    activeDivsClass,
    containerRef,
}: {
    activeDivsClass?: string;
    activeDivs?: any;
    divClass?: string;
    classname?: string;
    containerRef: React.RefObject<HTMLDivElement | null>;
}) {
    const [blocks, setBlocks] = useState<JSX.Element[]>([]);

    useEffect(() => {
        const updateBlocks = () => {
            const container = containerRef.current;
            if (container) {
                const containerWidth = container.clientWidth;
                const containerHeight = container.clientHeight;
                const blockSize = containerWidth * 0.04; // Using 6% of section width for the block size

                const columns = Math.floor(containerWidth / blockSize);
                const rows = Math.floor(containerHeight / blockSize);

                const newBlocks = Array.from({ length: columns }, (_, columnIndex) => (
                    // biome-ignore lint/suspicious/noArrayIndexKey: <explanation>
                    <div key={columnIndex} className='w-[6vw] h-full'>
                        {Array.from({ length: rows }, (_, rowIndex) => (
                            <div
                                // biome-ignore lint/suspicious/noArrayIndexKey: <explanation>
                                key={rowIndex}
                                className={cn(
                                    `h-[12vh] w-full border border-[#5dcece09] ${activeDivs[columnIndex]?.has(rowIndex) ? `${activeDivsClass}` : ''
                                    }`,
                                    divClass
                                )}
                                style={{ height: `${blockSize}px` }}
                            ></div>
                        ))}
                    </div>
                ));

                setBlocks(newBlocks);
            }
        };

        updateBlocks();
        window.addEventListener('resize', updateBlocks);

        return () => window.removeEventListener('resize', updateBlocks);
    }, [activeDivs, activeDivsClass, divClass, containerRef]);

    return (
        <div className={cn('flex h-full overflow-hidden top-0 bg-pr left-0 absolute', classname)}>
            {blocks}
        </div>
    );
}

export default Blocks;
